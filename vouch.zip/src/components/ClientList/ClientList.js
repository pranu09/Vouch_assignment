import './ClientList.css'


const ClientList = () => {
  return (
    <div className='w-100'>
    <div className='row'>
        {/* <div className='col-lg-3 col-md-6 pl-5' style={{border:"1px solid red"}}>
         sidebar
            </div> */}
        {/* <div className='col-lg-9 col-md-6'> */}
          mainbody
            {/* </div> */}
            </div>
            </div>
  )
}

export default ClientList;