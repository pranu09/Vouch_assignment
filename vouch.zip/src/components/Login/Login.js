import './Login.css'
import BackRect from '../../images/BackRectangle.png'
import BackRect2 from '../../images/Backrect2.png'
import { useEffect, useState } from 'react'
import { IconButton, InputAdornment, OutlinedInput, TextField } from '@mui/material'
import { AccountCircle, Visibility, VisibilityOff } from '@mui/icons-material'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'



const Login = () => {
const [email,setEmail] = useState("");
const [passwod,setPassword] = useState("");
const [showPassword, setShowPassword] = useState(false);
const [error,setError] = useState("");
const navigate = useNavigate();

useEffect(() => {
    if(localStorage.getItem('token')){
      navigate("/")
    }
  }, [])

const userLogin = async() => {
   const loginData = {
    email:"eve.holt@reqres.in",password:"5cityslicka"
   }
    try {
        const {data} = await axios.post("https://reqres.in/api/login",loginData);  
        console.log(data);
       if(data.token){
        localStorage.setItem('token',data.token);
        navigate("/")
       }
    } catch (error) {
        toast.error(error.response.data.error);
    }
}

const handleClickShowPassword = () => setShowPassword((show) => !show);

const handleMouseDownPassword = (event) => {
  event.preventDefault();
};

  return (
    <div className='container-fluid'>
    <div className='row'>
        <div className='col-lg-5'>
            <div className='loginForm d-flex justify-content-center align-items-center'>
                <div>
                <h1 onClick={userLogin}>Welcome</h1>
                <p>Enter your Username and Passoword.</p>
                <TextField
        //   id="outlined-password-input"
        //   label="Password"
          type="text"
        //   autoComplete="current-password"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <AccountCircle sx={{color:"#B8BABC;"}}/>
              </InputAdornment>
            ),
          }}
        />
              <OutlinedInput
            // id="outlined-adornment-password"
            type={showPassword ? 'text' : 'password'}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                //   aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />

         <div className='d-flex'>
          <img src="" alt="" />
          <input type="password" />
          <img src="" alt="" />
         </div>
                </div>
            </div>
        </div>
        <div className='col-lg-7'>
            <div className='loginRight'>
                <div className='ImgDiv'>
                    <img className='rectimg' src={BackRect} />
                    <img className='rectimg2' src={BackRect2} />
                </div>
                
            </div>

        </div>
    </div>
    </div>
  )
}

export default Login