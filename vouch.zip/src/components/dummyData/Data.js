export  const Data = [
    {
        logo: "./logo/Info.png",
        Company_name: "Infosys",
        Email_Address: "management@infosys.com",
        phone: "+91 9563214587",
        Contact_Person: "Vijayent Roy",
        Facilitator: "--",
        Sites: 12,
        Tenants: "--",
        Tenant_Groups: "--"

    },
    {
        logo: "./logo/wipro.png",

        Company_name: "Wipro",
        Email_Address: "management@wipro.com",
        phone: "+91 9834687423",
        Contact_Person: "Kalpit Soni",
        Facilitator: "--",
        Sites: 8,
        Tenants: "--",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/accenture.png",

        Company_name: "Accenture",
        Email_Address: "management@accenture.com",
        phone: "++91 8732654789",
        Contact_Person: "Drishti Sane",
        Facilitator: "--",
        Sites: 4,
        Tenants: "--",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/cap.png",

        Company_name: "Capgemini",
        Email_Address: "management@capgemini.com",
        phone: "+91 8432657995",
        Contact_Person: "Aisha Keer",
        Facilitator: "--",
        Sites: 6,
        Tenants: "--",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/L.png",

        Company_name: "Lodha",
        Email_Address: "management@lodha.com",
        phone: "+91 9642357894",
        Contact_Person: "Kanika Khare",
        Facilitator: "--",
        Sites: 24,
        Tenants: "16",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/tata.png",

        Company_name: "Tata Consultancy Services",
        Email_Address: "management@tcs.com",
        phone: "+91 9632457468",
        Contact_Person: "Prabhat Rao",
        Facilitator: "--",
        Sites: 10,
        Tenants: "--",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/hcl.png",

        Company_name: "HCL",
        Email_Address: "management@hcl.com",
        phone: "+91 9452136487",
        Contact_Person: "Venkat Pant",
        Facilitator: "--",
        Sites: 5,
        Tenants: "2",
        Tenant_Groups: "1"
    },
    {
        logo: "./logo/R.png",

        Company_name: "Redington",
        Email_Address: "management@redington.com",
        phone: "+91 9326571865",
        Contact_Person: "Samir Yadav",
        Facilitator: "--",
        Sites: 1,
        Tenants: "1",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/M.png",

        Company_name: "Mphasis",
        Email_Address: "management@mphasis.com",
        phone: "+91 9874621547",
        Contact_Person: "Sweta Chawla",
        Facilitator: "--",
        Sites: 1,
        Tenants: "--",
        Tenant_Groups: "--"
    },
    {
        logo: "./logo/LT.png",

        Company_name: "Larsen & Toubro",
        Email_Address: "management@larsentoubro.com",
        phone: "+91 9547154964",
        Contact_Person: "Abhishek Kumar",
        Facilitator: "--",
        Sites: 16,
        Tenants: "--",
        Tenant_Groups: "--"
    },

]